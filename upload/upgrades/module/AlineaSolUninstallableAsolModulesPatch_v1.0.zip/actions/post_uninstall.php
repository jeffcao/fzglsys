<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

  $gestor = fopen("modules/Administration/UpgradeHistory.php", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
			
			if (!strstr($buffer, "return false; //AlineaSolUninstallableAsolModulesPatch")){
				$fileText .= $buffer; 
				echo $buffer."<br>";
			}
    
		}
	
	fclose($gestor);
	
	$gestor = fopen("modules/Administration/UpgradeHistory.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }
  
?>
