<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


   $gestor = fopen("modules/Administration/UpgradeHistory.php", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while ((!feof($gestor)) && (!strstr($buffer, "function foundConflict(\$check_path, \$recent_path)"))) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer;
		}
			
		$buffer = fgets($gestor);
		
		$fileText .= "\t{\n\t\treturn false; //AlineaSolUninstallableAsolModulesPatch\n";
	
		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer; 
		}
	
	fclose($gestor);
	
	$gestor = fopen("modules/Administration/UpgradeHistory.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }
  
 
 ?>