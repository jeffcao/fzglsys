This tiny app is intended to fix the sugarcrm 6.5.10 module-self_referencing-bug.
It just overrides:
	- [sugar_instance_name]/data/Relationships/M2MRelationship.php
	- [sugar_instance_name]/data/Relationships/One2MRelationship.php
	- [sugar_instance_name]/data/Link2.php
When uninstalling this app: the three files are back to the originals.