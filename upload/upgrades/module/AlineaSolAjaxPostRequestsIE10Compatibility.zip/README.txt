This module fixes a bug on Javascript IE10 engine, that disables Ajax Post Requests.

To solve this problem, a meta-tag is added at the SugarCRM headers (by modifying '_head.tpl' file) to force the usage of IE9 Javascript Engine instead of the IE10 default one.

If you are not using this browser or an older version of IE, the behavior of your browser will be exactly the same as always.


The IE10 Browser issue results in imcompatibilities with:

	- SugarCRM ajaxUI navigation paradigm.
	- AlineaSolReports HTTP Requet Reports Features (including Http Request Dashlets).
	
	
After using the fix provided, all should work properly.