<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


	$gestor = fopen("themes/Sugar5/tpls/_head.tpl", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while ((!feof($gestor)) && (!strstr($buffer, "<head>"))) {
			$buffer = fgets($gestor);
			$fileText .= $buffer;
		}
		
		$fileText .= '<meta http-equiv="X-UA-Compatible" content="IE=9"> <!-- AlineaSolAjaxPostRequestsIE10Compatibility -->';
		$fileText .= "\n";
		
		while (!feof($gestor)) {
			
			$buffer = fgets($gestor);
			
			if (!strstr($buffer, '<meta http-equiv="X-UA-Compatible" content="IE=Edge" />')) {	
				$fileText .= $buffer; 
			}
			
		}
	
		fclose($gestor);
		
		$gestor = fopen("themes/Sugar5/tpls/_head.tpl", "w");
		fwrite($gestor, $fileText);
		
		fclose($gestor);
  
	}
  
 
 ?>