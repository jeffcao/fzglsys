<b>Executing post_install ...</b>

<?php

$GLOBALS['log']->debug('$_REQUEST=['.var_export($_REQUEST, true).']');

require_once("modules/asol_Process/___common_WFM/php/asol_utils.php");
require_once('modules/asol_Process/___common_WFM/php/checkConfigurationDefsFunctions.php');

global $sugar_config;

// Add scheduler wfm_engine_crontab
$aux_array = asol_CheckConfigurationDefsFunctions::checkSchedulerJob_boolean('wfm_engine_crontab');
$isValidScheduler = $aux_array['isValidScheduler'];
if ($isValidScheduler === null) {// NotSet
	addScheduler('wfm_engine_crontab', 'url::'.$sugar_config['site_url'].'/index.php?entryPoint=wfm_engine&execution_type=crontab');
}

// Add scheduler wfm_scheduled_task
$aux_array = asol_CheckConfigurationDefsFunctions::checkSchedulerJob_boolean('wfm_scheduled_task');
$isValidScheduler = $aux_array['isValidScheduler'];
if ($isValidScheduler === null) {// NotSet
	addScheduler('wfm_scheduled_task', 'url::'.$sugar_config['site_url'].'/index.php?entryPoint=wfm_scheduled_task');
}

// Repair wfm-task type=php_custom
repairPhpCustom();

// Repair Sugar Modules // FIXME sugarcrm 7.5
if (version_compare($sugar_config['sugar_version'], '7', '<')) {
	repairSugarModules('install'); 
}

// setAsolWorkFlowManagerCommon // FIXME sugarcrm 7.5
if (version_compare($sugar_config['sugar_version'], '7', '<')) {
	setAsolWorkFlowManagerCommon('cleanCache', 'true'); 
	setAsolWorkFlowManagerCommon('releaseVersion', '5.1'); // Do not use asolProjectUtils -> sugarcrm-module-loader will use the old asolProjectUtils, not the new.
}

// Remove backup // FIXME sugarcrm 7.5
if (version_compare($sugar_config['sugar_version'], '7', '<')) {
	removeBackup();
}

///////////////////
// AUX FUNCTIONS //
///////////////////

function repairPhpCustom() {

	global $db;

	$tasks = Array();

	$sql = "
		SELECT *
		FROM asol_task
		WHERE task_type = 'php_custom' AND deleted = 0
	";
	$query = $db->query($sql);
	while ($row = $db->fetchByAssoc($query)) {
		$tasks[] = $row;
	}

	foreach ($tasks as $task) {
		wfm_utils::wfm_SavePhpCustomToFile($task['id'], $task['task_implementation']);
	}
}

function addScheduler($scheduler_name, $scheduler_job){
	include_once('install/install_utils.php');
	require_once('modules/Schedulers/Scheduler.php');
	$scheduler = new Scheduler();

	$scheduler->name = $scheduler_name;
	$scheduler->job = $scheduler_job;
	$scheduler->date_time_start	= create_date(2005,1,1) .' '. create_time(0,0,1);
	$scheduler->date_time_end = null;
	$scheduler->job_interval = '*/1::*::*::*::*';
	$scheduler->status = 'Active';
	$scheduler->created_by = '1';
	$scheduler->modified_user_id = '1';
	$scheduler->catch_up = '1';

	$scheduler->save();
}

/**
 * BEGIN repairSugarModules
 */

function repairSugarModules($type) {

	echo '<b>Repair Sugar Modules:</b>';
	echo '<br>';

	repairRoles($type);
	//quickRepairAndRebuild();
	//rebuildRelationships();

}

function rebuildRelationships() {

	// Rebuild Relationships
	echo '<b>Rebuild Relationships...</b>';

	$_REQUEST['silent'] = true;
	global $beanFiles;
	include('include/modules.php');
	//require('modules/Administration/RebuildRelationship.php');

	//exit();

	VardefManager::clearVardef () ;
	Relationship::delete_cache () ;


	echo ' <b>Done.</b>';
	echo '<br>';
}


function install_beans($beans){
	include('include/modules.php');
	foreach($beans as $bean){
		if(isset($beanList[$bean])){
			$class = $beanList[$bean];
			if(file_exists($beanFiles[$class])){
				require_once($beanFiles[$class]);
				$mod = new $class();
				//#30273
				if(is_subclass_of($mod, 'SugarBean')  && $mod->disable_vardefs == false ){
					$GLOBALS['log']->debug( "Creating Tables Bean : $bean");
					$mod->create_tables();
					SugarBean::createRelationshipMeta($mod->getObjectName(), $mod->db,$mod->table_name,'',$mod->module_dir);
				}
			}else{
				$GLOBALS['log']->debug( "File Does Not Exist:" . $beanFiles[$class] );
			}
		}
	}
}

function uninstall_beans($beans){
	include('include/modules.php');
	foreach($beans as $bean){
		if(isset($beanList[$bean])){
			$class = $beanList[$bean];

			if(file_exists($beanFiles[$class])){
				require_once($beanFiles[$class]);
				$mod = new $class();

				if(is_subclass_of($mod, 'SugarBean')){
					$GLOBALS['log']->debug( "Drop Tables : $bean");
					if(isset($GLOBALS['mi_remove_tables']) && $GLOBALS['mi_remove_tables'])
					$mod->drop_tables();
				}
			}else{
				$GLOBALS['log']->debug( "File Does Not Exist:" . $beanFiles[$class] );
			}
		}
	}
}

function repairRoles($type) {

	// Repair Roles
	echo '<b>Repair Roles...</b>';
	echo '<br>';

	switch ($type) {
		case 'install':
			require('modules/ACL/remove_actions.php');
			addActions($new_modules);
			break;
		case 'uninstall':
			//require('modules/ACL/remove_actions.php');
			//require('modules/ACL/install_actions.php');
			break;
	}

	echo '<br>';
	echo ' <b>Done.</b>';
	echo '<br>';
}

function quickRepairAndRebuild() {

	// Quick Repair and Rebuild
	echo '<b>Quick Repair and Rebuild...</b>';

	// Repair and Rebuild
	$selected_actions = array('clearAll');
	$modules = array(translate('LBL_ALL_MODULES'), 'Administration');
	$autoexecute = true;
	$show_output = false;

	require_once ('modules/Administration/QuickRepairAndRebuild.php');
	$repair = new RepairAndClear();
	$repair->repairAndClearAll($selected_actions, $modules, $autoexecute, $show_output);
	// Repair and Rebuild

	echo ' <b>Done.</b>';
	echo '<br>';
}

function addActions() {

	global $current_user, $beanList, $beanFiles, $mod_strings;

	$GLOBALS['log']->debug('$beanList=['.var_export($beanList, true).']', __FILE__, __METHOD__, __LINE__);
	$GLOBALS['log']->debug('$beanFiles=['.var_export($beanFiles, true).']', __FILE__, __METHOD__, __LINE__);


	//*************************//
	//***ACL Install Actions***//
	//*************************//

	$newModules = Array(
		'asol_Process' => 'asol_Process',
		'asol_Events' => 'asol_Events',
		'asol_Activity' => 'asol_Activity',
		'asol_Task' => 'asol_Task',
		'asol_ProcessInstances' => 'asol_ProcessInstances',
		'asol_WorkingNodes' => 'asol_WorkingNodes',
		'asol_OnHold' => 'asol_OnHold',
		'asol_WorkFlowManagerCommon' => 'asol_WorkFlowManagerCommon',
	);
	wfm_utils::addPremiumModuleRoles($newModules, 'addModuleRoles_loginAudit');

	foreach ($newModules as $module=>$class) {
		require_once("modules/{$module}/{$class}.php");
		$mod = new $class();

		$GLOBALS['log']->info("**********[ASOL][WFM]: DOING {$class}");

		if($mod->bean_implements('ACL') && empty($mod->acl_display_only)){

			if(!isset($_REQUEST['upgradeWizard'])) {
				echo translate('LBL_ADDING','ACL','') . $mod->module_dir . '<br>';
			}

			if(!empty($mod->acltype)) {
				ACLAction::addActions($mod->getACLCategory(), $mod->acltype);
			} else {
				ACLAction::addActions($mod->getACLCategory());
			}

		}
	}

	//*************************//
	//***ACL Install Actions***//
	//*************************//

	$GLOBALS['log']->debug('$beanList=['.var_export($beanList, true).']', __FILE__, __METHOD__, __LINE__);
	$GLOBALS['log']->debug('$beanFiles=['.var_export($beanFiles, true).']', __FILE__, __METHOD__, __LINE__);
}

/**
 * END repairSugarModules
 */

function removeBackup() {
	$backup_path = clean_path( remove_file_extension(urldecode($_REQUEST['install_file']))."-restore" );
	$GLOBALS['log']->debug('$backup_path=['.var_export($backup_path, true).']', __FILE__, __METHOD__, __LINE__);
	delTree($backup_path);
}

function delTree($dir) {
	$files = array_diff(scandir($dir), array('.','..'));
	foreach ($files as $file) {
		(is_dir("$dir/$file") && !is_link($dir)) ? delTree("$dir/$file") : unlink("$dir/$file");
	}
	return rmdir($dir);
}

function setAsolWorkFlowManagerCommon($id, $value) {

	require_once("modules/asol_WorkFlowManagerCommon/asol_WorkFlowManagerCommon.php");
	$workFlowManagerCommon = new asol_WorkFlowManagerCommon();
	$workFlowManagerCommon->retrieve($id);

	if (empty($workFlowManagerCommon->id)) {
		$workFlowManagerCommon->new_with_id = true;
	}

	$workFlowManagerCommon->id = $id;
	$workFlowManagerCommon->name = $id;
	$workFlowManagerCommon->value = $value;

	$workFlowManagerCommon->save();
}

?>