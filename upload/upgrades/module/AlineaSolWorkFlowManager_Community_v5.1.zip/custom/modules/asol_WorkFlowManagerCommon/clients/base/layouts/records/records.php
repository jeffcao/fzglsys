<?php

$module = 'asol_WorkFlowManagerCommon';

$viewdefs[$module]['base']['layout']['records'] = array(
	'name' => 'bwc',
	'type' => 'bwc',
	'components' =>
		array(
			array(
				'view' => 'bwc',
			),
	),
);