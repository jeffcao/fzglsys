<?php

$module = 'asol_WorkingNodes';

$viewdefs[$module]['base']['layout']['records'] = array(
	'name' => 'bwc',
	'type' => 'bwc',
	'components' =>
		array(
			array(
				'view' => 'bwc',
			),
	),
);