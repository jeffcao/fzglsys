<?php

$bwcModules[] = 'asol_Process';
$bwcModules[] = 'asol_Events';
$bwcModules[] = 'asol_Activity';
$bwcModules[] = 'asol_Task';
$bwcModules[] = 'asol_ProcessInstances';
$bwcModules[] = 'asol_WorkingNodes';
$bwcModules[] = 'asol_OnHold';
$bwcModules[] = 'asol_LoginAudit';
$bwcModules[] = 'asol_WorkFlowManagerCommon';
