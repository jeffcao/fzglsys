<?php
// created: 2014-08-18 12:21:23
$dictionary["asol_Process"]["fields"]["asol_process_asol_events_1"] = array (
  'name' => 'asol_process_asol_events_1',
  'type' => 'link',
  'relationship' => 'asol_process_asol_events_1',
  'source' => 'non-db',
  'module' => 'asol_Events',
  'bean_name' => 'asol_Events',
  'side' => 'right',
  'vname' => 'LBL_ASOL_PROCESS_ASOL_EVENTS_1_FROM_ASOL_EVENTS_TITLE',
);
