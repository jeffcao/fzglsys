<?php
// created: 2014-08-18 12:21:23
$dictionary["asol_Process"]["fields"]["asol_process_asol_task"] = array (
  'name' => 'asol_process_asol_task',
  'type' => 'link',
  'relationship' => 'asol_process_asol_task',
  'source' => 'non-db',
  'module' => 'asol_Task',
  'bean_name' => 'asol_Task',
  'side' => 'right',
  'vname' => 'LBL_ASOL_PROCESS_ASOL_TASK_FROM_ASOL_TASK_TITLE',
);
