<?php
// created: 2011-03-22 13:25:17
$dictionary["asol_Process"]["fields"]["asol_process_asol_events"] = array (
  'name' => 'asol_process_asol_events',
  'type' => 'link',
  'relationship' => 'asol_process_asol_events',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ASOL_PROCESS_ASOL_EVENTS_FROM_ASOL_EVENTS_TITLE',
);
