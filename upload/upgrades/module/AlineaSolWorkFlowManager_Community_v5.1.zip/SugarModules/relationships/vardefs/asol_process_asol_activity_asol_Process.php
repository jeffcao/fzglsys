<?php
// created: 2014-08-18 12:21:23
$dictionary["asol_Process"]["fields"]["asol_process_asol_activity"] = array (
  'name' => 'asol_process_asol_activity',
  'type' => 'link',
  'relationship' => 'asol_process_asol_activity',
  'source' => 'non-db',
  'module' => 'asol_Activity',
  'bean_name' => 'asol_Activity',
  'side' => 'right',
  'vname' => 'LBL_ASOL_PROCESS_ASOL_ACTIVITY_FROM_ASOL_ACTIVITY_TITLE',
);
