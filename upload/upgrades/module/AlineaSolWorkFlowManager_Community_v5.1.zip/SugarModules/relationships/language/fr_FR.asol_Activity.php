<?php

$mod_strings['LBL_ASOL_ACTIVITY_ASOL_TASK_FROM_ASOL_TASK_TITLE'] = 'T&acirc;ches';
$mod_strings['LBL_ASOL_EVENTS_ASOL_ACTIVITY_FROM_ASOL_EVENTS_TITLE'] = 'Ev&eacute;nement';
$mod_strings['LBL_ASOL_ACTIVITY_ASOL_ACTIVITY_FROM_ASOL_ACTIVITY_L_TITLE'] = 'Activit&eacute;';
$mod_strings['LBL_ASOL_ACTIVITY_ASOL_ACTIVITY_FROM_ASOL_ACTIVITY_R_TITLE'] = 'Prochaine Activit&eacute;';
$mod_strings['LBL_ASOL_PROCESS_ASOL_ACTIVITY_FROM_ASOL_PROCESS_TITLE'] = 'Process';
