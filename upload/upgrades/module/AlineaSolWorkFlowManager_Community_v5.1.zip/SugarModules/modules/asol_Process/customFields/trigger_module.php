<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once("modules/asol_Process/___common_WFM/php/asol_utils.php");
wfm_utils::wfm_log('debug', "ENTRY", __FILE__);

require_once('trigger_module.generate_select.php');

echo $selectModules;

?>

<?php 
require_once("modules/asol_Process/___common_WFM/php/javascript_common_process_event_activity_task.php");
require_once("javascript.php");

?>