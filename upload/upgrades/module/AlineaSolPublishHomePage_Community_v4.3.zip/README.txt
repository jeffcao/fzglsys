//**************************************//
//******Config Override Features********//
//**************************************//

Activation of Features just configuring it at "config_override.php" file of your SugarCRM instance (just add the defined lines to this file):


	//********************************//
	//*******Community Features*******//
	//********************************//


	- Enabled Configuration to give HomePage's Management for Non-Admin Users at Role level:
		$sugar_config['AlineaSolPublishHomePageManagementRoles'] = array('Marketing');
	
	
	- Enabled Configuration that sets landing Page for admin users:
		$sugar_config['AlineaSolPublishHomePageAdminLandingRole'] = 'Sales';
	
	
	- Enabled Configuration that sets default new tab Hash Page:
		$sugar_config['AlineaSolPublishHomePageNewTabHash'] = 'YToyOntzOjg6ImRhc2hsZXRzIjthOjM6e3M6MzY6ImU1YmEwYjEyLTZjNDktOGUyZS0zY2NhLTRiNjZlNmUzMzgyZSI7YTo0OntzOjk6ImNsYXNzTmFtZSI7czoxNjoiTXlUaHJlYWRzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6MDoiIjtzOjEyOiJmaWxlTG9jYXRpb24iO3M6NjI6Im1vZHVsZXMvVGhyZWFkcy9EYXNobGV0cy9NeVRocmVhZHNEYXNobGV0L015VGhyZWFkc0Rhc2hsZXQucGhwIjtzOjEyOiJzb3J0X29wdGlvbnMiO2E6Mjp7czo5OiJzb3J0T3JkZXIiO3M6NDoiZGVzYyI7czo3OiJvcmRlckJ5IjtzOjE2OiJyZWNlbnRfcG9zdF9kYXRlIjt9fXM6MzY6ImUwYTYyN2NiLWM2YjQtOTkyNC0wZDBlLTRmMmFiNjE5OTdhYyI7YTo0OntzOjk6ImNsYXNzTmFtZSI7czoxNjoiU3VnYXJGZWVkRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6OToiU3VnYXJGZWVkIjtzOjc6Im9wdGlvbnMiO2E6MDp7fXM6MTI6ImZpbGVMb2NhdGlvbiI7czo2NDoibW9kdWxlcy9TdWdhckZlZWQvRGFzaGxldHMvU3VnYXJGZWVkRGFzaGxldC9TdWdhckZlZWREYXNobGV0LnBocCI7fXM6MzY6ImNkOGY0ZTFjLWU2ZTItYTIzMS0yNGVlLTRmMmFiNmQzZTFiZCI7YTo0OntzOjk6ImNsYXNzTmFtZSI7czoxNjoiU3VnYXJOZXdzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6NDoiSG9tZSI7czo3OiJvcHRpb25zIjthOjA6e31zOjEyOiJmaWxlTG9jYXRpb24iO3M6NTk6Im1vZHVsZXMvSG9tZS9EYXNobGV0cy9TdWdhck5ld3NEYXNobGV0L1N1Z2FyTmV3c0Rhc2hsZXQucGhwIjt9fXM6NToicGFnZXMiO2E6Mjp7aTowO2E6Mzp7czo3OiJjb2x1bW5zIjthOjI6e2k6MDthOjI6e3M6NToid2lkdGgiO3M6MzoiNjAlIjtzOjg6ImRhc2hsZXRzIjthOjE6e2k6MDtzOjM2OiJjZDhmNGUxYy1lNmUyLWEyMzEtMjRlZS00ZjJhYjZkM2UxYmQiO319aToxO2E6Mjp7czo1OiJ3aWR0aCI7czozOiI0MCUiO3M6ODoiZGFzaGxldHMiO2E6MTp7aTowO3M6MzY6ImUwYTYyN2NiLWM2YjQtOTkyNC0wZDBlLTRmMmFiNjE5OTdhYyI7fX19czoxMDoibnVtQ29sdW1ucyI7czoxOiIyIjtzOjk6InBhZ2VUaXRsZSI7czo4OiJNeSBTdWdhciI7fWk6MTthOjM6e3M6NzoiY29sdW1ucyI7YToyOntpOjA7YToyOntzOjU6IndpZHRoIjtzOjM6IjYwJSI7czo4OiJkYXNobGV0cyI7YTo1OntpOjA7czozNjoiNmI2Mjk3MGItN2VhMC0yZWFlLTA0NjctNGI5OTg3OGFkZDU5IjtpOjE7czozNjoiMjMwYmJhYTctYWJmZC0yMWExLTc0N2MtNGFlZTAxZDFiYTY4IjtpOjI7czozNjoiZGMzNDc2OGUtOWY2YS1lMzg5LTlmZTItNGFmODcyZWExNmQ2IjtpOjM7czozNjoiMjMxOGVkMGUtYTg5ZC1kMzBlLTJjYzktNGFlZTAxOTBjNjg0IjtpOjQ7czozNjoiMmE0NjRjODUtNTBhOC1hYzAyLTk5ZDEtNGNjMjlmZjg5Y2E4Ijt9fWk6MTthOjI6e3M6NToid2lkdGgiO3M6MzoiNDAlIjtzOjg6ImRhc2hsZXRzIjthOjU6e2k6MDtzOjM2OiIyMmVjNzJkYy03NjQ0LTJlNzEtNTA4Mi00YWVlMDE2MDI4YzAiO2k6MTtzOjM2OiI5MGFjOWVkZC05NTU0LWVlZTItNTZiYS00YmI5ZGI3ZTQ2MmYiO2k6MjtzOjM2OiJjZjliYjQ1NC1iMDQ5LWFjMDYtYmE5OS00YjE4MTk2MDQwZWUiO2k6MztzOjM2OiIyMmZjOTFkYi04OWFjLTdhMTYtMmJjNS00YWVlMDFjOWI5YmIiO2k6NDtzOjM2OiI1ZDdmNmIzMS1iNzJmLWU1ZWMtZTM1MS00ZDJlYzhkNWE4NjIiO319fXM6MTA6Im51bUNvbHVtbnMiO3M6MToiMiI7czo5OiJwYWdlVGl0bGUiO3M6MTQ6IkRhc2hib2FyZCBIb21lIjt9fX0=';*****************************


//**************************************//
//******Config Override Features********//
//**************************************//