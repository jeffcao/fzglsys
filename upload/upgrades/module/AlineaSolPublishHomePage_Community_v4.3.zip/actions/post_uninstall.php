<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $db;

//if remove tables option is set, remove roles_homepage table too
if (isset($_REQUEST['remove_tables']) && $_REQUEST['remove_tables']=='true') {
	
	$GLOBALS['log']->debug("*********************** ASOL: Removing from roles_homepage");
	$db->query("DROP TABLE roles_homepage");
	
} 


remove_logic_hook("Users", "after_save", array(1, "Set Home Page",  "custom/include/UserHooks.php", "UserHooks", "setHomePage"));
remove_logic_hook("Users", "after_retrieve", array(1, "Reset Homepage",  "custom/include/UserHooks.php", "UserHooks", "resetHomePage"));

	
//Modificamos el fichero entry_point_registry.php para eliminarle la entrada de los scheduledTasks de los Reports
$GLOBALS['log']->debug("**********[ASOL][PublishHomePAge]: Restoring entry_point_registry.php File");
  
$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");
	
if ($gestor) {
	
		$fileText = "";
	
		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
								   
			if (!strstr($buffer, "'getExportedHomepagesSQL' => array('file' => 'modules/Home/getExportedHomepagesSQL.php', 'auth' => true),")) {
				$fileText .= $buffer; 
				echo $buffer."<br>";
			}
    
		}
	
	fclose($gestor);
	
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
}

$GLOBALS['log']->debug("**********[ASOL][PublishHomePAge]: entry_point_registry.php file has been restored");
	
	

//Repair and Rebuild
$module = array('All Modules');
$selected_actions = array('clearJsFiles', 'clearTpls', 'clearJsFiles', 'clearDashlets', 'clearSugarFeedCache', 'clearThemeCache');

require_once ('modules/Administration/QuickRepairAndRebuild.php');
$randc = new RepairAndClear();
$randc->repairAndClearAll ( $selected_actions, $module, false, false );
//Repair and Rebuild
	

?>