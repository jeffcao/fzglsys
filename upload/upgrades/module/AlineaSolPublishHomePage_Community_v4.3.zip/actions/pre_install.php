<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $sugar_config, $db;
$db_name = $sugar_config['dbconfig']['db_name'];

	
//Editamos el fichero entry_point_registry.php para a�adirle un nuevo entry point para la scheduled Tasks de los Reports
 
   $gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while ((!feof($gestor)) && (!strstr($buffer, '$entry_point_registry = array('))) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer;
		}
	
		$fileText .= "\t'getExportedHomepagesSQL' => array('file' => 'modules/Home/getExportedHomepagesSQL.php', 'auth' => true),\n";
		echo "'getExportedHomepagesSQL' => array('file' => 'modules/Home/getExportedHomepagesSQL.php', 'auth' => true),<br>";

		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer; 
		}
	
	fclose($gestor);
	
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }
  
	
?>
