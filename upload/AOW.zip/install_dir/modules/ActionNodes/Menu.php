<?php 
global $mod_strings;
global $current_user;

$module_menu = Array( 
	Array("index.php?module=ActionNodes&action=index", "Listar", ""),
	Array("index.php?module=ActionNodes&action=EditView", "Crear", "s"),
);
?>

