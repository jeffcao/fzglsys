<?php 
global $mod_strings;
global $current_user;

$module_menu = Array( 
	Array("index.php?module=ChoiceNodes&action=index", "Listar", ""),
	Array("index.php?module=ChoiceNodes&action=EditView", "Crear", "s"),
);
?>
