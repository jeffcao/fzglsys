<?php
require_once('modules/gcoop_notificaciones/gcoop_notificaciones_sugar.php');
class gcoop_notificaciones extends gcoop_notificaciones_sugar {
	
	function gcoop_notificaciones(){	
		parent::gcoop_notificaciones_sugar();
	}
	
}
?>
