<?php
$viewdefs = array (
  'gcoop_notificaciones' => 
  array (
    'DetailView' => 
    array (
      'templateMeta' => 
      array (
        'form' => 
        array (
          'buttons' => 
          array (
          ),
          'hideAudit' => true,
        ),
        'maxColumns' => '2',
        'widths' => 
        array (
          0 => 
          array (
            'label' => '10',
            'field' => '30',
          ),
          1 => 
          array (
            'label' => '10',
            'field' => '30',
          ),
        ),
      ),
      'panels' => 
      array (
        'default' => 
        array (
          array (
              'idt24',
              'created_by_name',
          ),
          array (
              'description',
              '',
          ),
        ),
      ),
    ),
  ),
);

?>
