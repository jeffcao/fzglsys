<?php
$app_list_strings['moduleList']['ActionNodes'] = 'Action Node';
$app_list_strings['moduleList']['ChoiceNodes'] = 'Choice Node';
$app_list_strings['moduleList']['Workflows'] = 'Workflow';
$app_list_strings['moduleList']['Executions'] = 'Execution';
$app_list_strings['moduleList']['gcoop_notificaciones'] = 'Workflow Notification';
?>
